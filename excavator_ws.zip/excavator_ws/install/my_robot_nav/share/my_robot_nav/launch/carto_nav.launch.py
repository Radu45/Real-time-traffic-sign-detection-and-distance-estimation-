from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    nav2_pkg = get_package_share_directory('nav2_bringup')
    custom_nav_pkg = get_package_share_directory('my_robot_nav')
    carto_pkg = get_package_share_directory('cartographer_launch')  # <--

    return LaunchDescription([
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(carto_pkg, 'launch', 'cartographer.launch.py')
            ),
            launch_arguments={
                'use_sim_time': 'false',
                'configuration_basename': 'turtlebot4_lds_2d.lua',
                'params_file': os.path.join(custom_nav_pkg, 'bringup', 'nav2_params.yaml'),
            }.items()
        ),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(nav2_pkg, 'launch', 'bringup_launch.py')
            ),
            launch_arguments={
                'use_sim_time': 'false',
                'params_file': os.path.join(custom_nav_pkg, 'bringup', 'nav2_params.yaml'),
            }.items()
        )
    ])