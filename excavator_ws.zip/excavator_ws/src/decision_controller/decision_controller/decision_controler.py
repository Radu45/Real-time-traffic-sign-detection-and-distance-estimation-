import rclpy 
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge

class DecisionMaker(Node):

    def __init__(self):
        super().__init__('decision_maker')
        self.get_logger().info("Decision maker created!")
        self.subscription = self.create_subscription(
            String, 
            'decision',
            self.listener_callback,
            10
        )
        self.bridge = CvBridge()

    def listener_callback(self, msg):

        self.get_logger().info(f"[Decision Received] : {msg.data}")




def main(args=None):
    rclpy.init(args=args)
    node = DecisionMaker()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()