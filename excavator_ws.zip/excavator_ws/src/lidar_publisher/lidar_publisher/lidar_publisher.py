import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan
import serial
import struct
import math
import time

class LD19Publisher(Node):
    def __init__(self):
        super().__init__('lidar_publisher')
        self.publisher_ = self.create_publisher(LaserScan, 'laser', 10)

        # Initialize serial port
        self.ser = serial.Serial('/dev/ttyUSB0', 230400, timeout=0.1)
        self.get_logger().info('LD19 LiDAR connected to /dev/ttyUSB0')

        self.timer = self.create_timer(0.1, self.read_lidar_data)

        self.start_byte = b'\x54'
        self.header_size = 47  # 1 header + 1 ver_len + 1 speed_low + 1 speed_high + 2 timestamp + 1 CRC

    def read_lidar_data(self):
        if self.ser.in_waiting < self.header_size:
            return

        sync = self.ser.read(1)
        if sync != self.start_byte:
            return

        packet = self.ser.read(self.header_size - 1)
        if len(packet) != self.header_size - 1:
            return

        full_packet = self.start_byte + packet
        data = list(full_packet)

        # Parse distances and angles
        angle_offset = 6
        distances = []
        angles = []
        for i in range(12):
            byte_offset = angle_offset + i * 3
            if byte_offset + 2 >= len(data):
                continue
            distance = data[byte_offset] + ((data[byte_offset+1] & 0x3F) << 8)
            angle = ((data[byte_offset+1] & 0xC0) >> 6) + (i * 30 / 12)
            distances.append(distance / 1000.0)  # meters
            angles.append(math.radians(angle))

        # Publish LaserScan
        msg = LaserScan()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = "laser"
        msg.angle_min = min(angles)
        msg.angle_max = max(angles)
        msg.angle_increment = (msg.angle_max - msg.angle_min) / len(angles)
        msg.range_min = 0.12
        msg.range_max = 12.0
        msg.ranges = distances
        self.publisher_.publish(msg)
        self.get_logger().info("Published a scan")

def main(args=None):
    rclpy.init(args=args)
    node = LD19Publisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.ser.close()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
