import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
import smbus2
import time


class SimpleKalmanFilter:
    def __init__(self, process_variance, measurement_variance, estimated_value=0.0):
        self.process_variance = process_variance
        self.measurement_variance = measurement_variance
        self.estimated_error = 1.0
        self.current_estimate = estimated_value

    def update(self, measurement):
        kalman_gain = self.estimated_error / (self.estimated_error + self.measurement_variance)
        self.current_estimate += kalman_gain * (measurement - self.current_estimate)
        self.estimated_error = (1 - kalman_gain) * self.estimated_error + abs(self.current_estimate) * self.process_variance
        return self.current_estimate


class IMUPublisher(Node):
    def __init__(self):
        super().__init__('imu_publisher')
        self.publisher_ = self.create_publisher(Imu, 'imu', 10)
        self.timer = self.create_timer(0.1, self.publish_imu_data)  # 10 Hz

        self.bus = smbus2.SMBus(1)
        self.bus.write_byte_data(0x68, 0x6B, 0)  # Wake up MPU6050

        self.kf_x = SimpleKalmanFilter(0.01, 0.1)
        self.kf_y = SimpleKalmanFilter(0.01, 0.1)
        self.kf_z = SimpleKalmanFilter(0.01, 0.1)

        self.offset_x, self.offset_y, self.offset_z = self.calibrate()

    def read_accel(self):
        def read_word(reg):
            high = self.bus.read_byte_data(0x68, reg)
            low = self.bus.read_byte_data(0x68, reg + 1)
            val = (high << 8) + low
            if val >= 0x8000:
                val = -((65535 - val) + 1)
            return val

        x = read_word(0x3B)
        y = read_word(0x3D)
        z = read_word(0x3F)
        return x, y, z

    def calibrate(self):
        self.get_logger().info("Calibrating IMU...")
        sum_x = sum_y = sum_z = 0
        for _ in range(100):
            x, y, z = self.read_accel()
            sum_x += x
            sum_y += y
            sum_z += z
            time.sleep(0.01)
        avg_x = sum_x / 100
        avg_y = sum_y / 100
        avg_z = sum_z / 100
        return avg_x / 16384.0 * 9.80665, avg_y / 16384.0 * 9.80665, avg_z / 16384.0 * 9.80665

    def publish_imu_data(self):
        x, y, z = self.read_accel()
        x = self.kf_x.update((x / 16384.0 * 9.80665) - self.offset_x)
        y = self.kf_y.update((y / 16384.0 * 9.80665) - self.offset_y)
        z = self.kf_z.update((z / 16384.0 * 9.80665) - self.offset_z)

        msg = Imu()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'imu_link'

        msg.linear_acceleration.x = x
        msg.linear_acceleration.y = y
        msg.linear_acceleration.z = z

        # Orientation not available
        msg.orientation_covariance[0] = -1.0

        # Angular velocity set to 0.0 but must be present
        msg.angular_velocity.x = 0.0
        msg.angular_velocity.y = 0.0
        msg.angular_velocity.z = 0.0
        msg.angular_velocity_covariance[0] = 0.01
        msg.angular_velocity_covariance[4] = 0.01
        msg.angular_velocity_covariance[8] = 0.01

        self.publisher_.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = IMUPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

