import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge
import cv2
import numpy as np
from message_filters import Subscriber, ApproximateTimeSynchronizer
from ultralytics import YOLO

class DetectionDepthNode(Node):

    def __init__(self):
        super().__init__('depth_detector')
        self.get_logger().info("Depth detector node created")

        self.subscription_left = Subscriber(self, Image, '/left_camera/image_raw', qos_profile=qos_profile_sensor_data)
        self.subscription_right = Subscriber(self, Image, '/right_camera/image_raw', qos_profile=qos_profile_sensor_data)

        self.publisher_ = self.create_publisher(String, 'decision', 10)

        self.ts = ApproximateTimeSynchronizer(
            [self.subscription_left, self.subscription_right],
            queue_size=10,
            slop=0.1
        )
        self.ts.registerCallback(self.stereo_callback)
        self.get_logger().info("Synchronizer callback registered")

        self.bridge = CvBridge()
        self.model = YOLO('/home/radu28/Documents/Model_trained_YOLOv8/best.pt')

        self.K1 = np.load("/home/radu28/Documents/stereo_calibration_data/K1.npy")
        self.K2 = np.load("/home/radu28/Documents/stereo_calibration_data/K2.npy")
        self.E = np.load("/home/radu28/Documents/stereo_calibration_data/E.npy")
        self.F = np.load("/home/radu28/Documents/stereo_calibration_data/F.npy")
        self.D1 = np.load("/home/radu28/Documents/stereo_calibration_data/D1.npy")
        self.T = np.load("/home/radu28/Documents/stereo_calibration_data/T.npy")
        self.D2 = np.load("/home/radu28/Documents/stereo_calibration_data/D2.npy")
        self.R = np.load("/home/radu28/Documents/stereo_calibration_data/R.npy")

        self.baseline = 0.071  # meters
        self.image_size = (640, 480)
        self.R1, self.R2, self.P1, self.P2, self.Q, _, _ = cv2.stereoRectify(
            self.K1, self.D1, self.K2, self.D2, self.image_size, self.R, self.T
        )
        self.map1x, self.map1y = cv2.initUndistortRectifyMap(self.K1, self.D1, self.R1, self.P1, self.image_size, cv2.CV_32FC1)
        self.map2x, self.map2y = cv2.initUndistortRectifyMap(self.K2, self.D2, self.R2, self.P2, self.image_size, cv2.CV_32FC1)
        self.fx = self.K1[0, 0]

    def preprocess(self, frame):
        blurred = cv2.GaussianBlur(frame, (5, 5), 0.5)
        b, g, r = cv2.split(blurred)
        r = cv2.normalize(r, None, 0, 255, cv2.NORM_MINMAX)
        b = cv2.normalize(b, None, 0, 255, cv2.NORM_MINMAX)
        return cv2.merge((b, g, r))

    def extract_signs(self, results):
        signs = []
        for det in results.boxes:
            cls = int(det.cls[0])
            cx, cy = map(int, det.xywh[0][:2])
            signs.append((cls, cx, cy))
        return signs

    def annotate_frames(self, results, frame):
        for box in results.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            cls = int(box.cls[0])
            label = f"Class {cls}"
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        return frame

    def get_detection(self, results, cls, cx, cy, tolerance=30):
        for box in results.boxes:
            if int(box.cls[0]) != cls:
                continue
            box_cx, box_cy = map(int, box.xywh[0][:2])
            if abs(box_cx - cx) <= tolerance and abs(box_cy - cy) <= tolerance:
                return box_cx
        return None

    def stereo_callback(self, left_msg, right_msg):
        self.get_logger().info("Stereo callback is triggered")
        try:
            left_frame_raw = self.bridge.imgmsg_to_cv2(left_msg, desired_encoding="bgr8")
            right_frame_raw = self.bridge.imgmsg_to_cv2(right_msg, desired_encoding="bgr8")

            left_rect = cv2.remap(left_frame_raw, self.map1x, self.map1y, cv2.INTER_LINEAR)
            right_rect = cv2.remap(right_frame_raw, self.map2x, self.map2y, cv2.INTER_LINEAR)

            left_processed = self.preprocess(left_rect)
            right_processed = self.preprocess(right_rect)

            results_left = self.model(left_processed, imgsz=640)[0]
            results_right = self.model(right_processed, imgsz=640)[0]

            traffic_signs_left = self.extract_signs(results_left)
            traffic_signs_right = self.extract_signs(results_right)

            self.get_logger().info(f"Left signs: {traffic_signs_left}")
            self.get_logger().info(f"Right signs: {traffic_signs_right}")

            common_signs = []
            for (clsL, cxL, cyL) in traffic_signs_left:
                for (clsR, cxR, cyR) in traffic_signs_right:
                    if clsL == clsR  and abs(cyL - cyR) <= 60:
                        common_signs.append((clsL, cxL, cxR))

            self.get_logger().info(f"Common signs found: {common_signs}")

            for sign in common_signs:
                cls, cxL, cxR = sign

                if cxL is None or cxR is None:
                    continue
                disparity = abs(cxL - cxR)
                if disparity == 0:
                    continue
                depth = (self.fx * self.baseline) / disparity
                msg = String()
                msg.data = f"Class {cls}, Depth {depth:.2f} meters"
                self.publisher_.publish(msg)
                self.get_logger().info(f"[Depth Estimation]: Class {cls} at ~{depth:.2f} m")

            annotated_left = self.annotate_frames(results_left, left_rect)
            annotated_right = self.annotate_frames(results_right, right_rect)
            cv2.imshow("Left", annotated_left)
            cv2.imshow("Right", annotated_right)
            cv2.waitKey(1)

        except Exception as e:
            self.get_logger().error(f"Frames not captured: {str(e)}")


def main(args=None):
    rclpy.init(args=args)
    node = DetectionDepthNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()