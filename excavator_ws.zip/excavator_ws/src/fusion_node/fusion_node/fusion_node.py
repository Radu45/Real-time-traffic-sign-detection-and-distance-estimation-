import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from cv_bridge import CvBridge
from sensor_msgs.msg import Imu
from message_filters import Subscriber, ApproximateTimeSynchronizer
import serial
import struct
import math
import time
import cv2 



class FusionNode(Node):

    def __init__(self):

        #Defining the converter 
        self.bridge = CvBridge()

        # Subscribing to IMU and lidat
        self.subscription_lidar = Subscriber(self, LaserScan, 'scan')
        self.subscription_IMU = Subscriber(self, Imu, 'imu/data_raw')

        # As the method is called one time per topic , we need to define a synchronizer such that we work with corresponding Lidar points and IMU frame
        self.ts = ApproximateTimeSynchronizer(
            [self.subscription_lidar, self.subscription_IMU],
            queue_size = 10,
            slop = 0.1 # maximum time difference in seconds 
        )

        self.ts.registerCallback(self.point_cloud_callback)


    def point_cloud_callback(self, msg_lidar, msg_IMU):

        laserScan = msg_lidar.msg_to








