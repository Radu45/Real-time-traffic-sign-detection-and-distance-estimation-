import rclpy 
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2

class StereoCameraPublisher(Node):

    def __init__(self):
        super().__init__('camera_publisher')

        # This converts the cv2 to ROS message and vice versa
        self.br = CvBridge()

        # Left camera publisher
        gst_left = (
            'libcamerasrc camera-name="/base/axi/pcie@120000/rp1/i2c@80000/imx219@10" ! '
            'video/x-raw,width=640,height=480,format=NV12,framerate=30/1 ! '
            'videoconvert ! appsink'
        )

        # Right camera GStreamer pipeline
        gst_right = (
            'libcamerasrc camera-name="/base/axi/pcie@120000/rp1/i2c@88000/imx219@10" ! '
            'video/x-raw,width=640,height=480,format=NV12,framerate=30/1 ! '
            'videoconvert ! appsink'
        )

        # Capture frames from left cameras
        self.cap_left = cv2.VideoCapture(gst_left, cv2.CAP_GSTREAMER)

        # Capture frames from right camera 
        self.cap_right = cv2.VideoCapture(gst_right, cv2.CAP_GSTREAMER)

        if not self.cap_right.isOpened() or not self.cap_left.isOpened():
            self.get_logger().error("Failed to open one or both camera streams")
            return

        # Now we create the 2 publishers
        self.pub_left = self.create_publisher(Image, '/left_camera/image_raw', 10)
        self.pub_right = self.create_publisher(Image, '/right_camera/image_raw', 10)

        self.timer = self.create_timer(1.0/30.0, self.timer_callback)

    def timer_callback(self):

        retL, frameL = self.cap_left.read()
        retR, frameR = self.cap_right.read()

        if not retL or frameL is None:
          self.get_logger().info("left frame not captured")

        if not retR or frameR is None:
          self.get_logger().info("right frame not captured")

        
        msgL = self.br.cv2_to_imgmsg(frameL, encoding='rgb8')
        msgR = self.br.cv2_to_imgmsg(frameR, encoding='rgb8')

        self.pub_left.publish(msgL)
        self.pub_right.publish(msgR)
        self.get_logger().info("Published left and right frames")
        
    def destroy_node(self):
        self.cap_left.release()
        self.cap_right.release()
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = StereoCameraPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()





